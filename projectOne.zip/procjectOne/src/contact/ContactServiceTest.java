package contact;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class ContactServiceTest {
    private ContactService contactService;

    @Before
    public void setUp() {
        // Initialize ContactService before each test
        contactService = new ContactService();
    }

    @Test
    public void testAddContactSuccessfully() {
        // Create a new Contact object
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Fake St");

        // Add the contact to the ContactService
        contactService.addContact(contact);

        // Retrieve the contact from the ContactService and check if it's the same as the one added
        assertEquals(contact, contactService.getContact("1234567890"));
    }

    @Test
    public void testDeleteContactSuccessfully() {
        // Create a new Contact object
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Fake St");

        // Add the contact to the ContactService
        contactService.addContact(contact);

        // Delete the contact from the ContactService
        contactService.deleteContact("1234567890");

        // Check if the contact has been deleted
        assertNull(contactService.getContact("1234567890"));
    }

    @Test
    public void testUpdateContactFirstNameSuccessfully() {
        // Create a new Contact object
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Fake St");

        // Add the contact to the ContactService
        contactService.addContact(contact);

        // Update contact's first name
        contactService.updateFirstName("1234567890", "Jane");

        // Retrieve the updated contact
        Contact updatedContact = contactService.getContact("1234567890");

        // Check that the first name has been updated correctly
        assertEquals("Jane", updatedContact.getFirstName());
    }

    @Test
    public void testUpdateContactLastNameSuccessfully() {
        // Create a new Contact object
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Fake St");

        // Add the contact to the ContactService
        contactService.addContact(contact);

        // Update contact's last name
        contactService.updateLastName("1234567890", "Smith");

        // Retrieve the updated contact
        Contact updatedContact = contactService.getContact("1234567890");

        // Check that the last name has been updated correctly
        assertEquals("Smith", updatedContact.getLastName());
    }

    @Test
    public void testUpdateContactPhoneSuccessfully() {
        // Create a new Contact object
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Fake St");

        // Add the contact to the ContactService
        contactService.addContact(contact);

        // Update contact's phone
        contactService.updatePhone("1234567890", "9876543210");

        // Retrieve the updated contact
        Contact updatedContact = contactService.getContact("1234567890");

        // Check that the phone has been updated correctly
        assertEquals("9876543210", updatedContact.getPhone());
    }

    @Test
    public void testUpdateContactAddressSuccessfully() {
        // Create a new Contact object
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Fake St");

        // Add the contact to the ContactService
        contactService.addContact(contact);

        // Update contact's address
        contactService.updateAddress("1234567890", "456 Bogus St");

        // Retrieve the updated contact
        Contact updatedContact = contactService.getContact("1234567890");

        // Check that the address has been updated correctly
        assertEquals("456 Bogus St", updatedContact.getAddress());
    }
}
