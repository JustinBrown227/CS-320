package contact;

import static org.junit.Assert.*;
import org.junit.Test;

public class ContactTest {

    @Test
    public void testContactCreationWithValidAttributes() {
        // Create a new Contact object
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Fake St");

        // Check that the contact object is not null
        assertNotNull(contact);
    }

    @Test
    public void testContactIDIsSetCorrectly() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Fake St");
        assertEquals("1234567890", contact.getContactID());
    }

    @Test
    public void testFirstNameIsSetCorrectly() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Fake St");
        assertEquals("John", contact.getFirstName());
    }

    @Test
    public void testLastNameIsSetCorrectly() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Fake St");
        assertEquals("Doe", contact.getLastName());
    }

    @Test
    public void testPhoneIsSetCorrectly() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Fake St");
        assertEquals("1234567890", contact.getPhone());
    }

    @Test
    public void testAddressIsSetCorrectly() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Fake St");
        assertEquals("123 Fake St", contact.getAddress());
    }

    @Test
    public void testUpdateFirstNameSuccessfully() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Fake St");
        contact.updateFirstName("Jane");
        assertEquals("Jane", contact.getFirstName());
    }

    @Test
    public void testUpdateLastNameSuccessfully() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Fake St");
        contact.updateLastName("Smith");
        assertEquals("Smith", contact.getLastName());
    }

    @Test
    public void testUpdatePhoneSuccessfully() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Fake St");
        contact.updatePhone("9876543210");
        assertEquals("9876543210", contact.getPhone());
    }

    @Test
    public void testUpdateAddressSuccessfully() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Fake St");
        contact.updateAddress("456 Bogus St");
        assertEquals("456 Bogus St", contact.getAddress());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testUpdateFirstNameWithNullThrowsException() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Fake St");
        contact.updateFirstName(null);
    }
}
