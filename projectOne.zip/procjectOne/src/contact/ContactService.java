package contact;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    // Map to store contacts, where the key is the contact ID and the value is the Contact object
    private final Map<String, Contact> contacts;

    // Constructor to initialize the map
    public ContactService() {
        this.contacts = new HashMap<>();
    }

    // Method to add a contact
    public void addContact(Contact contact) {
        contacts.put(contact.getContactID(), contact);
    }

    // Method to delete a contact by contact ID
    public void deleteContact(String contactID) {
        contacts.remove(contactID);
    }

    // Method to update the first name of a contact by contact ID
    public void updateFirstName(String contactID, String firstName) {
        Contact contact = contacts.get(contactID);
        if (contact != null) {
            contact.updateFirstName(firstName);
        }
    }

    // Method to update the last name of a contact by contact ID
    public void updateLastName(String contactID, String lastName) {
        Contact contact = contacts.get(contactID);
        if (contact != null) {
            contact.updateLastName(lastName);
        }
    }

    // Method to update the phone number of a contact by contact ID
    public void updatePhone(String contactID, String phone) {
        Contact contact = contacts.get(contactID);
        if (contact != null) {
            contact.updatePhone(phone);
        }
    }

    // Method to update the address of a contact by contact ID
    public void updateAddress(String contactID, String address) {
        Contact contact = contacts.get(contactID);
        if (contact != null) {
            contact.updateAddress(address);
        }
    }

    // Method to retrieve a contact by contact ID
    public Contact getContact(String contactID) {
        return contacts.get(contactID);
    }
}

