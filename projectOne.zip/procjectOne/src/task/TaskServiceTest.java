package task;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
    private TaskService taskService;

    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
    }

    @Test
    public void testAddTask() {
        Task task = new Task("1", "Test Task", "This is a test description.");
        taskService.addTask(task);
        assertEquals(task, taskService.getTask("1"));
    }

    @Test
    public void testAddTaskWithDuplicateId() {
        Task task1 = new Task("1", "Test Task 1", "This is a test description 1.");
        Task task2 = new Task("1", "Test Task 2", "This is a test description 2.");
        taskService.addTask(task1);
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            taskService.addTask(task2);
        });
        assertEquals("Task ID already in use.", exception.getMessage());
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("1", "Test Task", "This is a test description.");
        taskService.addTask(task);
        taskService.deleteTask("1");
        assertNull(taskService.getTask("1"));
    }

    @Test
    public void testDeleteNonExistentTask() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            taskService.deleteTask("nonexistent");
        });
        assertEquals("Task not found.", exception.getMessage());
    }

    @Test
    public void testUpdateTaskName() {
        Task task = new Task("1", "Test Task", "This is a test description.");
        taskService.addTask(task);
        taskService.updateTaskName("1", "Updated Task");
        assertEquals("Updated Task", taskService.getTask("1").getName());
    }

    @Test
    public void testUpdateTaskDescription() {
        Task task = new Task("1", "Test Task", "This is a test description.");
        taskService.addTask(task);
        taskService.updateTaskDescription("1", "Updated description.");
        assertEquals("Updated description.", taskService.getTask("1").getDescription());
    }

    @Test
    public void testUpdateTaskNameWithInvalidTaskId() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTaskName("invalidId", "Updated Task");
        });
        assertEquals("Task not found.", exception.getMessage());
    }

    @Test
    public void testUpdateTaskDescriptionWithInvalidTaskId() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTaskDescription("invalidId", "Updated description.");
        });
        assertEquals("Task not found.", exception.getMessage());
    }
}
