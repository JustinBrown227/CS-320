package task;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    // Hash map to store tasks
    private final Map<String, Task> tasks = new HashMap<>();

    // Method to add task to the service
    public void addTask(Task task) {
        // Checks if task ID is already used
        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task ID already in use.");
        }
        tasks.put(task.getTaskId(), task);
    }

    // Method to delete a task using task ID
    public void deleteTask(String taskId) {
        tasks.remove(taskId);
    }

    // Method to update the name task using task ID
    public void updateTaskName(String taskId, String name) {
        Task task = tasks.get(taskId);
        // Check if task exists
        if (task != null) {
            task.setName(name);
        } else {
        	// Message that displays if task is not found.
            throw new IllegalArgumentException("Task not found.");
        }
    }

    // Method to update the description of a task using task ID
    public void updateTaskDescription(String taskId, String description) {
        Task task = tasks.get(taskId);
        // Check if task exists
        if (task != null) {
            task.setDescription(description);
        } else {
        	// Message that displays if task is not found.
            throw new IllegalArgumentException("Task not found.");
        }
    }

    // Method to retrieve a task using task ID
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
}
