package task;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    // Test creating a valid task
    @Test
    public void testValidTaskCreation() {
        Task task = new Task("12345", "Test Task", "This is a test description.");
        assertEquals("12345", task.getTaskId());
        assertEquals("Test Task", task.getName());
        assertEquals("This is a test description.", task.getDescription());
    }

    // Test creating a task with empty taskId
    @Test
    public void testNullTaskId() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Test Task", "This is a test description.");
        });
        assertEquals("Task ID cannot be empty and cannot be greater than 10 characters.", exception.getMessage());
    }

    // Test creating a task with taskId greater than 10 characters
    @Test
    public void testLongTaskId() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Test Task", "This is a test description.");
        });
        assertEquals("Task ID cannot be empty and cannot be greater than 10 characters.", exception.getMessage());
    }

    // Test creating a task with empty name
    @Test
    public void testNullName() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", null, "This is a test description.");
        });
        assertEquals("Name cannot be empty and cannot be greater than 20 characters.", exception.getMessage());
    }

    // Test creating a task with name greater than 20 characters
    @Test
    public void testLongName() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "This is a very long task name", "This is a test description.");
        });
        assertEquals("Name cannot be empty and cannot be greater than 20 characters.", exception.getMessage());
    }

    // Test creating a task with empty description
    @Test
    public void testNullDescription() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Test Task", null);
        });
        assertEquals("Description cannot be empty and cannot be greater than 50 characters.", exception.getMessage());
    }

    // Test creating a task with description greater than 50 characters
    @Test
    public void testLongDescription() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Test Task", "This is a very long description that exceeds the 50 characters limit.");
        });
        assertEquals("Description cannot be empty and cannot be greater than 50 characters.", exception.getMessage());
    }

    // Test setting a valid name
    @Test
    public void testSetName() {
        Task task = new Task("12345", "Initial Name", "Initial description.");
        task.setName("New Name");
        assertEquals("New Name", task.getName());
    }

    // Test setting a name that is empty
    @Test
    public void testSetNameNull() {
        Task task = new Task("12345", "Initial Name", "Initial description.");
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            task.setName(null);
        });
        assertEquals("Name cannot be empty and cannot be greater than 20 characters.", exception.getMessage());
    }

    // Test setting a name greater than 20 characters
    @Test
    public void testSetNameLong() {
        Task task = new Task("12345", "Initial Name", "Initial description.");
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            task.setName("This is a very long task name that exceeds 20 characters.");
        });
        assertEquals("Name cannot be empty and cannot be greater than 20 characters.", exception.getMessage());
    }

    // Test setting a valid description
    @Test
    public void testSetDescription() {
        Task task = new Task("12345", "Initial Name", "Initial description.");
        task.setDescription("New description.");
        assertEquals("New description.", task.getDescription());
    }

    // Test setting a description that is empty
    @Test
    public void testSetDescriptionNull() {
        Task task = new Task("12345", "Initial Name", "Initial description.");
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription(null);
        });
        assertEquals("Description cannot be empty and cannot be greater than 50 characters.", exception.getMessage());
    }

    // Test setting a description greater than 50 characters
    @Test
    public void testSetDescriptionLong() {
        Task task = new Task("12345", "Initial Name", "Initial description.");
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription("This is a very long description that exceeds the 50 characters limit.");
        });
        assertEquals("Description cannot be empty and cannot be greater than 50 characters.", exception.getMessage());
    }
}
