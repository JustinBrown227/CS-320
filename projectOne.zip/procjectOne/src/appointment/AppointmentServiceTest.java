package appointment;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;

public class AppointmentServiceTest {
    @Test
    public void testAddAppointment() {
        // Create the service
        AppointmentService service = new AppointmentService();
        // Create a date in the future
        Date futureDate = new Date(System.currentTimeMillis() + 86400000); // 1 day in the future
        // Create an appointment
        Appointment appointment = new Appointment("1234567890", futureDate, "Description");
        // Add the appointment to the service
        service.addAppointment(appointment);
        // Verify the appointment was added
        assertEquals(appointment, service.getAppointment("1234567890"));
    }

    @Test
    public void testAddDuplicateAppointment() {
        // Create the service
        AppointmentService service = new AppointmentService();
        // Create a date in the future
        Date futureDate = new Date(System.currentTimeMillis() + 86400000); // 1 day in the future
        // Create an appointment
        Appointment appointment = new Appointment("1234567890", futureDate, "Description");
        // Add the appointment to the service
        service.addAppointment(appointment);
        // Verify that adding a duplicate appointment throws an exception
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appointment);
        });
    }

    @Test
    public void testDeleteAppointment() {
        // Create the service
        AppointmentService service = new AppointmentService();
        // Create a date in the future
        Date futureDate = new Date(System.currentTimeMillis() + 86400000); // 1 day in the future
        // Create an appointment
        Appointment appointment = new Appointment("1234567890", futureDate, "Description");
        // Add the appointment to the service
        service.addAppointment(appointment);
        // Delete the appointment from the service
        service.deleteAppointment("1234567890");
        // Verify the appointment was deleted
        assertNull(service.getAppointment("1234567890"));
    }

    @Test
    public void testDeleteNonExistentAppointment() {
        // Create the service
        AppointmentService service = new AppointmentService();
        // Verify that deleting a non-existent appointment throws an exception
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("1234567890");
        });
    }
}
