package appointment;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;

public class AppointmentTest {
    @Test
    public void testAppointmentCreationSuccess() {
        // Create a date in the future
        Date futureDate = new Date(System.currentTimeMillis() + 86400000); // 1 day in the future
        // Create an appointment with valid data
        Appointment appointment = new Appointment("1234567890", futureDate, "Description");
        // Verify the appointment's properties
        assertEquals("1234567890", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Description", appointment.getDescription());
    }

    @Test
    public void testInvalidAppointmentId() {
        // Create a date in the future
        Date futureDate = new Date(System.currentTimeMillis() + 86400000); // 1 day in the future
        // Verify that creating an appointment with a null ID throws an exception
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Description");
        });
        // Verify that creating an appointment with an ID longer than 10 characters throws an exception
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Description");
        });
    }

    @Test
    public void testInvalidAppointmentDate() {
        // Create a date in the past
        Date pastDate = new Date(System.currentTimeMillis() - 86400000); // 1 day in the past
        // Verify that creating an appointment with a past date throws an exception
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", pastDate, "Description");
        });
    }

    @Test
    public void testInvalidDescription() {
        // Create a date in the future
        Date futureDate = new Date(System.currentTimeMillis() + 86400000); // 1 day in the future
        // Verify that creating an appointment with a null description throws an exception
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", futureDate, null);
        });
        // Verify that creating an appointment with a description longer than 50 characters throws an exception
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", futureDate, "This description is way too long and should not be allowed");
        });
    }
}
